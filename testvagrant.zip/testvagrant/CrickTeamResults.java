package com.testvagrant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;



public class CrickTeamResults {
	String name;
	int points;
	char[] results;

	public CrickTeamResults(String name, int points, char[] results) {
		super();
	    this.name = name;
		this.points = points;
		this.results = results;
	}

//  method for finding 2 consecutive losses
	public static ArrayList<String> results(ArrayList<CrickTeamResults> a)

	{
		ArrayList<String> tname = new ArrayList<>();

		for (CrickTeamResults crickTeamResults : a) {
			int count = 0;
			char[] results = crickTeamResults.results;
            for (int i = 1; i < crickTeamResults.results.length; i++) {
				if (results[i - 1] == 'l' && results[i] == 'l') {
					count++;

                     if (count == 1) {
						tname.add(crickTeamResults.name);
					}
				}
			}
               }
		return tname;
	}
//  method for finding n cosecutive losses or wins
	  public static ArrayList<CrickTeamResults> consecutiveResults(ArrayList<CrickTeamResults> a) {
		Scanner sc = new Scanner(System.in);
        	System.out.println("Enter the number of consecutive win or loss");
		int num = sc.nextInt();
		System.out.println("Enter w or l");
		char c = sc.next().toLowerCase().charAt(0);

		ArrayList<CrickTeamResults> tname = new ArrayList<>();

		for (CrickTeamResults crickTeamResults : a) {
			int count = 0;
			char[] results = crickTeamResults.results;

			for (int i = 1; i < crickTeamResults.results.length; i++) {

				if (results[i - 1] == c && results[i] == c) {
					count++;
					if (count == num - 1) {

						tname.add(crickTeamResults);
                                }
		           }
         	      }
		}
		return tname;
	}

	@Override
	public String toString() {
		return "CrickTeamResults [name=" + name + ", points=" + points + ", results=" + Arrays.toString(results) + "]";
	}
	 
	
 }



