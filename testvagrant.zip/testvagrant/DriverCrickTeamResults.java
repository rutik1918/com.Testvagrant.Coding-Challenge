package com.testvagrant;

import java.util.ArrayList;

public class DriverCrickTeamResults {

public static void main(String[] args) {
	 try {
		
     ArrayList<CrickTeamResults> a=new ArrayList<>();
	
	a.add(new CrickTeamResults("GT", 20, new char[] {'w', 'w', 'l', 'l', 'w'}));
	a.add(new CrickTeamResults("LSG",18, new char[] {'w', 'l', 'l', 'w', 'w'}));
	a.add(new CrickTeamResults("RR", 16, new char[] {'w', 'l', 'w', 'l', 'l'}));
	a.add(new CrickTeamResults("DC", 14, new char[] {'w', 'w', 'l', 'W', 'L'}));
	a.add(new CrickTeamResults("RCB",14, new char[] {'l', 'w', 'w', 'L', 'L'}));
	a.add(new CrickTeamResults("KKR",12, new char[] {'l', 'w', 'w', 'L', 'W'}));
	a.add(new CrickTeamResults("PBKS",12,new char[] {'l', 'w', 'l', 'w', 'l'}));
	a.add(new CrickTeamResults("SRH",12, new char[] {'w', 'l', 'l', 'l', 'l'}));
	a.add(new CrickTeamResults("CSK",8, new char[] {'l', 'l', 'w', 'l', 'w'}));
	a.add(new CrickTeamResults("MI", 6, new char[] {'l', 'w', 'l', 'w', 'w'}));
	 
	  System.out.println("Teams Added Sucessfully");
	  System.out.println("1.Teams with two Consecutive Losses are :");
  //		 calling method 1
	   System.out.println(CrickTeamResults.results(a));
 //	      calling method 2  
	   ArrayList<CrickTeamResults> teams = CrickTeamResults.consecutiveResults(a) ;
	   int sum=0 ; 
	   System.out.println("Teams are : ");
	  for(CrickTeamResults team : teams) {
		  System.out.println(team);
		  sum = sum + team.points ;
	  }
	  //	to give Average Points
     System.out.println("3.The average points of filtered teams is :" + sum/teams.size());
     
	  } 

     catch (ArithmeticException e) {
	               System.out.println("There are no teams with this result ");
	         }
          }
   }

